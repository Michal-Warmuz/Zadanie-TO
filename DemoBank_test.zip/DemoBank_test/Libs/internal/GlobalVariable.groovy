package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile demobank_dev : Nazwa u&#380;ytkownika</p>
     */
    public static Object user
     
    /**
     * <p>Profile demobank_dev : Strona do logowania</p>
     */
    public static Object url_login
     
    /**
     * <p>Profile demobank_dev : Has&#322;o u&#380;ytkownika</p>
     */
    public static Object pwd
     
    /**
     * <p>Profile demobank_dev : NUmer rachunku bankowego</p>
     */
    public static Object rachunek
     
    /**
     * <p>Profile demobank_dev : Odbiorca przelewu</p>
     */
    public static Object odbiorca
     
    /**
     * <p>Profile demobank_dev : Adres do przelewu</p>
     */
    public static Object url_pay
     
    /**
     * <p>Profile demobank_dev : Tytu&#322; przelewu</p>
     */
    public static Object tytul
     
    /**
     * <p></p>
     */
    public static Object kwota
     
    /**
     * <p></p>
     */
    public static Object pozostala_kwota
     
    /**
     * <p></p>
     */
    public static Object stala_kwota
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            user = selectedVariables['user']
            url_login = selectedVariables['url_login']
            pwd = selectedVariables['pwd']
            rachunek = selectedVariables['rachunek']
            odbiorca = selectedVariables['odbiorca']
            url_pay = selectedVariables['url_pay']
            tytul = selectedVariables['tytul']
            kwota = selectedVariables['kwota']
            pozostala_kwota = selectedVariables['pozostala_kwota']
            stala_kwota = selectedVariables['stala_kwota']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
