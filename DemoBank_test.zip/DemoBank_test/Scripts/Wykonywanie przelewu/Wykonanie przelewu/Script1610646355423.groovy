import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przegladarki i wejscie na strone
 */
WebUI.openBrowser(GlobalVariable.url_login)

/*
 * Wprowadzenie nazwy uzytkownika
 */
WebUI.setText(findTestObject('Object Repository/Page_Login/input_login'), GlobalVariable.user)

/*
* Kliknięcie przycisku dalej
*/
WebUI.click(findTestObject('Object Repository/Page_Login/btn_next'))

/*
 * Wprowadzenie hasła użytkownika
 */
WebUI.setText(findTestObject('Object Repository/Page_Login/input_password'), GlobalVariable.pwd)



/*
 * Kliknięcie przycisku zaloguj
 */
 WebUI.click(findTestObject('Object Repository/Page_Login/btn_next'))
 
 /*
  * Przejscie do sekcji płatnosci
  */
 
 WebUI.navigateToUrl(GlobalVariable.url_pay)
 
 /*
  * Wprowadzenie odbiorcy
  */
 WebUI.setText(findTestObject('Object Repository/Page_Przelew/input_odbiorca'), GlobalVariable.odbiorca)
 
 /*
  * Wprowadzenie numeru rachunku
  */
 WebUI.setText(findTestObject('Object Repository/Page_Przelew/input_rachunek'), GlobalVariable.rachunek)
 
 /*
  * Wprowadzenie kwoty
  */
 WebUI.setText(findTestObject('Object Repository/Page_Przelew/input_kwota'), GlobalVariable.kwota)
 
 /*
  * Wprowadzenie tytułu
  */
 WebUI.setText(findTestObject('Object Repository/Page_Przelew/textarea_title'), GlobalVariable.tytul)

 
 str_result = WebUI.getText(findTestObject('Object Repository/Page_Przelew/strong_poz_kw'));
 
 assert str_result == GlobalVariable.pozostala_kwota
 
 /*
  * Kliknięcie przycisku dalej
  */
  WebUI.click(findTestObject('Object Repository/Page_Przelew/btn_next_red'))
  
str_new_resul = WebUI.getText(findTestObject('Object Repository/Page_Przelew/strong_poz_kw'))

assert str_new_resul == GlobalVariable.stala_kwota
  

WebUI.closeBrowser()
  