<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS02 - Wykonanie przelewu</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>fd11e749-d49b-48e3-b284-4b846ddde945</testSuiteGuid>
   <testCaseLink>
      <guid>d8a10ae0-e353-4ee9-a384-203667b2acca</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Wykonywanie przelewu/Wykonanie przelewu</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
