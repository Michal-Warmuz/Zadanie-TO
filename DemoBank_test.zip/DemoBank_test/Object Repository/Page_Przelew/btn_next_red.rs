<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_next_red</name>
   <tag></tag>
   <elementGuidId>5448f16f-6677-46c9-8b3e-86945bb383b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[class=&quot;btn red arrow&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
